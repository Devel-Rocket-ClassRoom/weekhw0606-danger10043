#include "Player.h"
#include "itemdata.h"
#include "colorprint.h"
#include "basic.h"
#include <string>
#include <queue>

void Player::ShowInventory() {
	std::queue<std::string> inventoryPrintBuffer;
	std::string inventoryTempText = "";

	printf("\n");
	printUILine((INVENTORY_UI_WIDTH - 10) / 2, 1, 0, false);
	printf("[====== 인벤토리 ======]");
	printUILine(0, 1, (INVENTORY_UI_WIDTH - 10) / 2, true);
	printUILine(1, INVENTORY_UI_WIDTH - 2, 1, true);

	for (auto it = Inventory.begin(); it != Inventory.end(); it++) {
		if (it->second <= 0 && it->first != 0)
			continue;

		inventoryTempText = ColorText(ItemID2NameColor[it->first], ItemID2ItemName[it->first]);
		inventoryTempText += " : " + std::to_string(it->second);
		//inventoryTempText = ItemID2ItemName[it->first] + " : " + std::to_string(it->second);
		while (getTextWidth(inventoryTempText) < (3 * INVENTORY_UI_WIDTH - 12) / 2) {
			inventoryTempText += " ";
		}
		inventoryPrintBuffer.push(inventoryTempText);
	}

	int totalRow = (static_cast<int>(inventoryPrintBuffer.size()) + 1) / 2;
	
	for (int row = 0; row < totalRow; row++) {
		if (inventoryPrintBuffer.empty()) {
			break;
		}
		printUILine(0, 2, 0, false);
		printf("%s", inventoryPrintBuffer.front().c_str());
		inventoryPrintBuffer.pop();
		if (inventoryPrintBuffer.empty()) {
			printf("\n");
			break;
		}
		printf("%s\n", inventoryPrintBuffer.front().c_str());
		inventoryPrintBuffer.pop();
	}
	printUILine(1, INVENTORY_UI_WIDTH - 2, 1, true);
	printUILine(INVENTORY_UI_WIDTH, 0, 0, true);
	printf("\n");
}

void Player::ShowStat() {
	TempTextLine = "체력 : [" + std::to_string(Health) + " / " + std::to_string(MaxHealth) + "]    /    " + "방어력 : " + std::to_string(DefensePower);
	TextBuffer.push(TempTextLine);
	TempTextLine = "채광력 : " + std::to_string(MiningPower) + "    /    " + "공격력 : " + std::to_string(AttackPower + WeaponPower);
	TextBuffer.push(TempTextLine);
	TempTextLine = "현재 손에 든 아이템 : " + ColorText(ItemID2NameColor[HandItemID], ItemID2ItemName[HandItemID]);
	TextBuffer.push(TempTextLine);
	TempTextLine.clear();
}

int Player::heal(int healAmount) {
	int realHealAmount = (std::min)(MaxHealth - Health, healAmount);
	Health += realHealAmount;
	return realHealAmount;
}

int Player::damage(int damageAmount) {
	Health -= damageAmount;
	return damageAmount;
}

void Player::clearInventory() {
	Inventory.clear();
	Health = 200;
	HandItemID = 0;
	AttackPower = 10;
	WeaponPower = 0;
	MiningPower = 0;
	DefensePower = 0;
}
