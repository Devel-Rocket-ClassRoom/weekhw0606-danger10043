#pragma once
#include <map>

class Player {
public:
	int posR = 0, posC = 0;
	std::map<int, int> Inventory;

	int Health = 200;
	int MaxHealth = 200;
	int HandItemID = 0;
	int AttackPower = 10;
	int WeaponPower = 0;
	int MiningPower = 0;
	int DefensePower = 0;

	void ShowInventory();

	void ShowStat();

	int heal(int healAmount);

	int damage(int damageAmount);

	void clearInventory();


};