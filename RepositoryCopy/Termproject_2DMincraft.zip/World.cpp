#include "World.h"
#include "Block.h"
#include "Basic.h"
#include "random.h"
#include "itemData.h"
#include "colorprint.h"
#include "battle.h"
#include "item.h"
#include <iostream>
#include <vector>

void World::GenerateWorld() {
		world = std::vector<std::vector<Block>>(WORLD_HEIGHT, std::vector<Block>(WORLD_WIDTH, Block()));
		for (int row = 0; row < WORLD_HEIGHT; row++) {
			for (int column = 0; column < WORLD_WIDTH; column++) {

				// 월드 기본 생성
				if (row <= 7) {
					world[row][column].itemID = 0;
				}
				else if (row == 8) {
					world[row][column].itemID = 2;
				}
				else if (row >= 9 && row <= 12) {
					world[row][column].itemID = 3;
				}
				else {
					world[row][column].itemID = 1;

					if (row >= 15) {
						// 석탄 생성
						if (RandomIntRange(1, 1000) >= 950) {
							world[row][column].itemID = 16;
						}
					}
					if (row >= 18) {
						// 철 생성
						if (RandomIntRange(1, 1000) >= 950) {
							world[row][column].itemID = 15;
						}
					}
					if (row >= 27) {
						// 철 생성
						if (RandomIntRange(1, 1000) >= 950) {
							world[row][column].itemID = 14;
						}
					}
					if (row >= 35) {
						// 다이아몬드 생성
						if (RandomIntRange(1, 1000) >= 970) {
							world[row][column].itemID = 56;
						}
					}
				}
				world[row][column].posR = row;
				world[row][column].posC = column;
				world[row][column].ColorNoise[0] = RandomIntRange(-10, 10);
				world[row][column].ColorNoise[1] = RandomIntRange(-10, 10);
				world[row][column].ColorNoise[2] = RandomIntRange(-10, 10);
			}
		}

		// 나무 생성
		std::vector<int> treePosList = RandomIntRange(0, WORLD_WIDTH - 1, RandomIntRange(2, 4));
		for (int treePos : treePosList) {
			plantTree(7, treePos);
		}

		// 플레이어 생성
		player.posR = 7;
		player.posC = WORLD_WIDTH / 2;
		world[player.posR][player.posC].itemID = -1;

		//// 테스트 블럭 생성
		//world[player.posR - 1][player.posC].itemID = 61;
}

void World::plantTree(int worldPosR, int worldPosC) {
	int StemHeight = RandomIntRange(3, 5);

	for (int h = 0; h < StemHeight; h++) {
		if (worldPosR - h < 0)
			break;
		world[worldPosR - h][worldPosC].itemID = 17;
	}
	for (int h = StemHeight - 2; h < StemHeight + 2; h++) {
		if (worldPosR - h < 0)
			break;
		if (h < StemHeight) {
			for (int c = -2; c <= 2; c++) {
				if (worldPosC + c < 0 || worldPosC + c >= WORLD_WIDTH)
					continue;
				if (c == 0)
					continue;
				world[worldPosR - h][worldPosC + c].itemID = 18;
			}
		}
		else if (h == StemHeight) {
			for (int c = -2; c <= 2; c++) {
				if (worldPosC + c < 0 || worldPosC + c >= WORLD_WIDTH)
					continue;
				world[worldPosR - h][worldPosC + c].itemID = 18;
			}
		}
		else {
			for (int c = -1; c <= 1; c++) {
				if (worldPosC + c < 0 || worldPosC + c >= WORLD_WIDTH)
					continue;
				world[worldPosR - h][worldPosC + c].itemID = 18;
			}
		}
	}
}

void World::SwitchItem() {


	// 2. 아이템 이름 입력받기
	TextBuffer.push("손에 들고자 하는 아이템의 이름을 입력하세요.");
	TextBuffer.push("(취소하려면 \"X\"를 입력) : ");
	printWorld();

	// 1. 보유한 아이템 출력하기
	player.ShowInventory();

	printf("입력 : ");
	std::string Input; std::cin.ignore(); std::getline(std::cin, Input);
	if (Input == "X" || Input == "x")
		return;

	// 3. 손에 든 아이템 설정하기
	if (ItemName2ItemID[Input] == 0 || player.Inventory[ItemName2ItemID[Input]] <= 0) {
		TextBuffer.push("보유하지 않은 아이템이거나 올바른 입력이 아닙니다.");
		return;
	}
	player.HandItemID = ItemName2ItemID[Input];
	TempTextLine = "손에 [" + Input + "] 아이템을 들었습니다.";
	TextBuffer.push(TempTextLine);
}

void World::PlaceBlock() {
	// 1. 손에 든 아이템이 블럭인지 확인하기
	if (player.HandItemID < 1 || player.HandItemID > 255) {
		TextBuffer.push("현재 손에 든 아이템은 설치할 수 있는 아이템이 아닙니다.");
		return;
	}

	// 2. 설치할 방향 입력받기
	TextBuffer.push("블럭을 설치할 위치를 입력하세요.");
	TextBuffer.push("( 플레이어 위치를 기준으로, 상:w, 좌:a, 하:s, 우:d, 취소:x )");
	printWorld();
	printf("입력 : ");
	char Direction; std::cin >> Direction;

	// 3. 해당 위치가 블럭 설치가 가능한지 확인하기
	int targetR = 0, targetC = 0;
	switch (Direction) {
	case 'w':
		targetR = player.posR - 1;
		targetC = player.posC;
		break;
	case 's':
		targetR = player.posR + 1;
		targetC = player.posC;
		break;
	case 'a':
		targetR = player.posR;
		targetC = player.posC - 1;
		break;
	case 'd':
		targetR = player.posR;
		targetC = player.posC + 1;
		break;
	case 'x':
	case 'X':
		return;
	}
	if (world[targetR][targetC].itemID != 0) {
		TextBuffer.push("해당 위치에는 블럭을 설치할 수 없습니다.");
		return;
	}

	// 4. 월드 해당 위치에 블럭 생성하기
	world[targetR][targetC].itemID = player.HandItemID;
	world[targetR][targetC].ColorNoise[0] = RandomIntRange(-10, 10);
	world[targetR][targetC].ColorNoise[1] = RandomIntRange(-10, 10);
	world[targetR][targetC].ColorNoise[2] = RandomIntRange(-10, 10);

	// 5. 플레이어 인벤토리에서 블럭 1개 제거하기
	player.Inventory[player.HandItemID]--;
	if (player.Inventory[player.HandItemID] == 0) {
		player.HandItemID = 0;
	}

	TempTextLine = ItemID2ItemName[world[targetR][targetC].itemID] + " 1개를 설치하였습니다.";
	TextBuffer.push(ItemID2ItemName[world[targetR][targetC].itemID] + " 1개를 설치하였습니다.");
	TextBuffer.push("현재 " + ItemID2ItemName[world[targetR][targetC].itemID] + " 보유 개수 : " + std::to_string(player.Inventory[world[targetR][targetC].itemID]) + "개");
	currentTime = (currentTime + 1) % 180;
}

void World::craft() {
	// 1. 조합법 모두 표시, 가능한 조합법은 밝은 색으로 표시
	// TODO : Craft 출력 개선
	std::queue<std::string> craftPrintBuffer;
	std::string craftTempText = "";

	printf("\n");
	printUILine((CRAFT_UI_WIDTH - 14) / 2, 1, 0, false);
	printf("[======== 조합 아이템 목록 ========]");
	printUILine(0, 1, (CRAFT_UI_WIDTH - 14) / 2, true);
	printUILine(1, CRAFT_UI_WIDTH - 2, 1, true);

	for (const auto& recipe : RECIPEBOOK) {
		std::vector<std::pair<int, int>> meterials = recipe.first;
		std::pair<int, int> result = recipe.second;

		craftTempText.clear();
		bool IsCraftable = true;
		for (std::pair<int, int> meterial : meterials) {
			if (player.Inventory[meterial.first] < meterial.second) {
				IsCraftable = false;
			}
			if (meterial.second < 0) {
				if (
					(world[range(player.posR - 1, 0, WORLD_HEIGHT)][player.posC].itemID != meterial.first) &&
					(world[range(player.posR + 1, 0, WORLD_HEIGHT)][player.posC].itemID != meterial.first) &&
					(world[player.posR][range(player.posC + 1, 0, WORLD_HEIGHT)].itemID != meterial.first) &&
					(world[player.posR][range(player.posC - 1, 0, WORLD_HEIGHT)].itemID != meterial.first)
					) {
					IsCraftable = false;
				}
			}

			if (meterial.second > 0) {
				craftTempText += ItemID2ItemName[meterial.first] + " " + std::to_string(meterial.second) + "개";
				craftTempText += " + ";
			}
			else {
				craftTempText.pop_back();
				craftTempText.pop_back();
				craftTempText += "(" + ItemID2ItemName[meterial.first] + " 필요)   ";
			}
		}
		craftTempText.pop_back();
		craftTempText.pop_back();
		craftTempText += "--> ";
		craftTempText += ItemID2ItemName[result.first] + " " + std::to_string(result.second) + "개";

		while (getTextWidth(craftTempText) < (3 * CRAFT_UI_WIDTH - 12) / 2) {
			craftTempText += " ";
		}

		if (IsCraftable) {
			craftPrintBuffer.push(ColorText({ 0, 255, 255 }, craftTempText));
		}
		else {
			craftPrintBuffer.push(ColorText({ 160, 160, 160 }, craftTempText));
		}


	}
	int totalRow = (static_cast<int>(craftPrintBuffer.size()) + 1) / 2;

	for (int row = 0; row < totalRow; row++) {
		if (craftPrintBuffer.empty()) {
			break;
		}
		printUILine(0, 2, 0, false);
		printf("%s", craftPrintBuffer.front().c_str());
		craftPrintBuffer.pop();
		if (craftPrintBuffer.empty()) {
			printf("\n");
			break;
		}
		printf("%s\n", craftPrintBuffer.front().c_str());
		craftPrintBuffer.pop();
	}
	printUILine(1, CRAFT_UI_WIDTH - 2, 1, true);
	printUILine(CRAFT_UI_WIDTH, 0, 0, true);
	printf("\n");

	// 2. 사용자에게 "X" 또는 아이템 이름 입력
	printf("조합하고자 하는 아이템의 이름을 입력하세요(취소하려면 \"X\"를 입력) : ");
	std::string Input; std::cin.ignore(); std::getline(std::cin, Input);
	if (Input == "X" || Input == "x")
		return;

	bool IsItemExist = false;
	bool IsCraftable = true;
	bool IsNearTable = true;
	int MaxCraftCount = 65535;
	std::vector<std::pair<int, int>> TargetMeterials;
	std::pair<int, int> TargetResult;

	for (const auto& recipe : RECIPEBOOK) {
		std::vector<std::pair<int, int>> meterials = recipe.first;
		std::pair<int, int> result = recipe.second;

		if (ItemID2ItemName[result.first] == Input) {
			IsItemExist = true;
			TargetMeterials = meterials;
			TargetResult = result;
			for (std::pair<int, int> meterial : meterials) {
				if (meterial.second > 0) {
					if (player.Inventory[meterial.first] < meterial.second) {
						IsCraftable = false;
						break;
					}
					MaxCraftCount = min(MaxCraftCount, player.Inventory[meterial.first] / meterial.second);
				}
				else {
					if (
						(world[range(player.posR - 1, 0, WORLD_HEIGHT)][player.posC].itemID != meterial.first) &&
						(world[range(player.posR + 1, 0, WORLD_HEIGHT)][player.posC].itemID != meterial.first) &&
						(world[player.posR][range(player.posC + 1, 0, WORLD_HEIGHT)].itemID != meterial.first) &&
						(world[player.posR][range(player.posC - 1, 0, WORLD_HEIGHT)].itemID != meterial.first)
						) {
						IsNearTable = false;
						break;
					}
				}
			}
		}
	}

	if (!IsItemExist) {
		TextBuffer.push("존재하지 않는 아이템 이름입니다.");
		return;
	}
	if (!IsCraftable) {
		TextBuffer.push("재료가 부족하여 제작할 수 없는 아이템입니다.");
		return;
	}
	if (!IsNearTable) {
		TextBuffer.push("적절한 작업 블럭이 근처에 없어 제작할 수 없습니다.");
		return;
	}

	// 2-1. 조합 횟수 입력 받기
	printf("조합 횟수를 정수로 입력하세요. (최대 조합 가능 횟수 : %d회) : ", MaxCraftCount);
	int CraftCount; std::cin >> CraftCount;
	if (CraftCount > MaxCraftCount) {
		TextBuffer.push("조합할 수 없는 수량입니다.");
		return;
	}

	// 3. 가능한 아이템 입력한 경우 조합 처리
	std::string CraftText = "";

	for (std::pair<int, int> meterial : TargetMeterials) {
		if (meterial.second > 0) {
			player.Inventory[meterial.first] -= CraftCount * meterial.second;
			CraftText += ItemID2ItemName[meterial.first] + " " + std::to_string(CraftCount * meterial.second) + "개, ";
		}
	}
	CraftText.pop_back();
	CraftText.pop_back();
	CraftText += "를 사용했습니다.";
	TextBuffer.push(CraftText);
	CraftText.clear();
	CraftText = ItemID2ItemName[TargetResult.first] + " " + std::to_string(CraftCount * TargetResult.second) + "개를 제작했습니다.";
	TextBuffer.push(CraftText);
	if (TargetResult.first == 270 && player.MiningPower < 1) {
		player.MiningPower = 1;
		TextBuffer.push("채광력이 상승하여 더 많은 블록을 캘 수 있습니다!");
	}
	if (TargetResult.first == 274 && player.MiningPower < 2) {
		player.MiningPower = 2;
		TextBuffer.push("채광력이 상승하여 더 많은 블록을 캘 수 있습니다!");
	}
	if (TargetResult.first == 257 && player.MiningPower < 3) {
		player.MiningPower = 3;
		TextBuffer.push("채광력이 상승하여 더 많은 블록을 캘 수 있습니다!");
	}
	if (TargetResult.first == 278 && player.MiningPower < 4) {
		player.MiningPower = 4;
		TextBuffer.push("채광력이 상승하여 더 많은 블록을 캘 수 있습니다!");
	}

	if (TargetResult.first == 268 && player.WeaponPower < 15) {
		player.WeaponPower = 15;
		TextBuffer.push("공격력이 상승하여 전투 시 더 많은 피해를 입힙니다.");
	}
	if (TargetResult.first == 272 && player.WeaponPower < 20) {
		player.WeaponPower = 20;
		TextBuffer.push("공격력이 상승하여 전투 시 더 많은 피해를 입힙니다.");
	}
	if (TargetResult.first == 267 && player.WeaponPower < 25) {
		player.WeaponPower = 25;
		TextBuffer.push("공격력이 상승하여 전투 시 더 많은 피해를 입힙니다.");
	}
	if (TargetResult.first == 283 && player.WeaponPower < 30) {
		player.WeaponPower = 30;
		TextBuffer.push("공격력이 상승하여 전투 시 더 많은 피해를 입힙니다.");
	}
	if (TargetResult.first == 276 && player.WeaponPower < 40) {
		player.WeaponPower = 40;
		TextBuffer.push("공격력이 상승하여 전투 시 더 많은 피해를 입힙니다.");
	}

	player.Inventory[TargetResult.first] += CraftCount * TargetResult.second;
}

void World::giveItem() {
	TempTextLine = "아이템 코드와 개수를 각각 정수로 입력하세요.";
	TextBuffer.push(TempTextLine);
	printWorld();
	printf("입력 : ");
	int itemID, itemCount; std::cin >> itemID >> itemCount;
	player.Inventory[itemID] += itemCount;
	TempTextLine = "플레이어에게 " + ItemID2ItemName[itemID] + " " + std::to_string(itemCount) + "개를 지급했습니다.";
	TextBuffer.push(TempTextLine);
	TempTextLine.clear();

	if (itemID == 270 && player.MiningPower < 1) {
		player.MiningPower = 1;
		TextBuffer.push("[ 나무 곡괭이 ] 를 획득하였습니다!");
		TextBuffer.push("채광력이 상승하여 더 많은 블록을 캘 수 있습니다.");
	}
	if (itemID == 274 && player.MiningPower < 2) {
		player.MiningPower = 2;
		TextBuffer.push("[ 돌 곡괭이 ] 를 획득하였습니다!");
		TextBuffer.push("채광력이 상승하여 더 많은 블록을 캘 수 있습니다.");
	}
	if (itemID == 257 && player.MiningPower < 3) {
		player.MiningPower = 3;
		TextBuffer.push("[ 철 곡괭이 ] 를 획득하였습니다!");
		TextBuffer.push("채광력이 상승하여 더 많은 블록을 캘 수 있습니다.");
	}
	if (itemID == 278 && player.MiningPower < 4) {
		player.MiningPower = 4;
		TextBuffer.push("[ 다이아몬드 곡괭이 ] 를 획득하였습니다!");
		TextBuffer.push("채광력이 상승하여 더 많은 블록을 캘 수 있습니다.");
	}
	if (itemID == 268 && player.WeaponPower < 15) {
		player.WeaponPower = 15;
		TextBuffer.push("[ 나무 검 ] 를 획득하였습니다!");
		TextBuffer.push("공격력이 상승하여 전투 시 더 많은 피해를 입힙니다.");
	}
	if (itemID == 272 && player.WeaponPower < 20) {
		player.WeaponPower = 20;
		TextBuffer.push("[ 돌 검 ] 를 획득하였습니다!");
		TextBuffer.push("공격력이 상승하여 전투 시 더 많은 피해를 입힙니다.");
	}
	if (itemID == 267 && player.WeaponPower < 25) {
		player.WeaponPower = 25;
		TextBuffer.push("[ 철 검 ] 를 획득하였습니다!");
		TextBuffer.push("공격력이 상승하여 전투 시 더 많은 피해를 입힙니다.");
	}
	if (itemID == 283 && player.WeaponPower < 30) {
		player.WeaponPower = 30;
		TextBuffer.push("[ 금 검 ] 를 획득하였습니다!");
		TextBuffer.push("공격력이 상승하여 전투 시 더 많은 피해를 입힙니다.");
	}
	if (itemID == 276 && player.WeaponPower < 40) {
		player.WeaponPower = 40;
		TextBuffer.push("[ 다이아몬드 검 ] 를 획득하였습니다!");
		TextBuffer.push("공격력이 상승하여 전투 시 더 많은 피해를 입힙니다.");
	}
}

void World::printWorld() {
	std::system("cls");
	for (int row = 0; row < 2 * LENS_HEIGHT_SIZE + 5; row++) {
		if (row == 0 || row == 2 * LENS_HEIGHT_SIZE + 4) {
			for (int column = 0; column < 2 * LENS_WIDTH_SIZE + 4; column++) {
				PrintWithColor({ 128, 128, 100 }, { 128, 128, 100 }, "   ");
			}
			for (int column = 0; column < INTERVAL_MAP_WITH_CONSOLE; column++) {
				printf("   ");
			}
			printUILine(3 * LENS_WIDTH_SIZE + 4, 0, 0, true);
		}
		else if (row == 1 || row == 2 * LENS_HEIGHT_SIZE + 3) {
			PrintWithColor({ 128, 128, 100 }, { 128, 128, 100 }, "   ");
			for (int column = 0; column < 2 * LENS_WIDTH_SIZE + 2; column++) {
				printf("   ");
			}
			PrintWithColor({ 128, 128, 100 }, { 128, 128, 100 }, "   ");

			for (int column = 0; column < INTERVAL_MAP_WITH_CONSOLE; column++) {
				printf("   ");
			}
			printUILine(1, 3 * LENS_WIDTH_SIZE + 2, 1, true);
		}
		else {
			PrintWithColor({ 128, 128, 100 }, { 128, 128, 100 }, "   ");
			printf("   ");
			int tempRow = row - 2 + player.posR - LENS_HEIGHT_SIZE;
			for (int tempColumn = player.posC - LENS_WIDTH_SIZE; tempColumn < player.posC + LENS_WIDTH_SIZE; tempColumn++) {
				if (tempRow < 0 || tempRow >= WORLD_HEIGHT || tempColumn < 0 || tempColumn >= WORLD_WIDTH) {
					printf("   ");
					continue;
				}
				world[max(min(tempRow, WORLD_HEIGHT - 1), 0)][max(min(tempColumn, WORLD_WIDTH - 1), 0)].printBlock(currentTime, 10);
			}
			printf("   ");
			PrintWithColor({ 128, 128, 100 }, { 128, 128, 100 }, "   ");

			for (int column = 0; column < INTERVAL_MAP_WITH_CONSOLE; column++) {
				printf("   ");
			}
			printf("   ");
			if (row % 2 == 0 && !TextBuffer.empty()) {
				printf("   ");
				std::string TempText = TextBuffer.front(); TextBuffer.pop();
				while (TempText.length() < 6 * LENS_WIDTH_SIZE + 3) {
					TempText += " ";
				}
				std::cout << TempText;
			}
			else {
				for (int column = 0; column < 2 * LENS_WIDTH_SIZE + 2; column++) {
					printf("   ");
				}
			}
			printf("   ");
			printf("\n");

		}
	}
	printf("\n");
}

bool World::playerMine(int worldPosR, int worldPosC) {
	if (world[worldPosR][worldPosC].itemID != 0) {

		if (world[worldPosR][worldPosC].getStrength() > player.MiningPower) {
			TempTextLine = ColorText({ 225, 90, 90 }, "채광력이 부족하여 해당 블럭을 부술 수 없습니다.");
			TextBuffer.push(TempTextLine);
			TempTextLine = ColorText({ 225, 90, 90 }, std::to_string(world[worldPosR][worldPosC].getStrength()) + " 이상의 채광력이 필요합니다.");
			TextBuffer.push(TempTextLine);
			return false;
		}
		int gotItemID = world[worldPosR][worldPosC].getItem();
		if (gotItemID != -1) {
			player.Inventory[gotItemID]++;
			// 채광 완료 및 현재 보유 개수 출력 함수
			TempTextLine = "[" + ItemID2ItemName[gotItemID] + "] 을(를) 획득했습니다!";
			TextBuffer.push(TempTextLine);
			TempTextLine = "현재 " + ItemID2ItemName[gotItemID] + " 보유 개수 : " + std::to_string(player.Inventory[gotItemID]) + "개";
			TextBuffer.push(TempTextLine);
			TempTextLine.clear();
		}
		world[worldPosR][worldPosC].itemID = 0;
	}
	return true;
}

void World::playerMove(char direction) {
	int tempPosR = player.posR, tempPosC = player.posC;
	switch (direction) {
	case 'w':
		tempPosR = max(0, player.posR - 1);
		break;
	case 'a':
		tempPosC = max(0, player.posC - 1);
		break;
	case 's':
		tempPosR = min(WORLD_HEIGHT - 1, player.posR + 1);
		break;
	case 'd':
		tempPosC = min(WORLD_WIDTH - 1, player.posC + 1);
		break;
	}
	if (playerMine(tempPosR, tempPosC)) {
		world[player.posR][player.posC].itemID = 0;
		world[tempPosR][tempPosC].itemID = -1;
		player.posR = tempPosR;
		player.posC = tempPosC;
		currentTime = (currentTime + 1) % 180;
		tryBattle();
	}
}

//낮 : t <= 120 or t >= 170
//밤 : 120 < t < 170

void World::tryBattle() {
	if (player.posR <= 12 && (currentTime <= 120 || currentTime >= 170)) {
		int randomValue = rand() % 200;

		// 0.5% = 돼지
		if (randomValue == 1) {
			battle(player, 90);
		}
		// 0.5% = 양
		else if (randomValue == 2) {
			battle(player, 91);
		}
		// 0.5% = 소
		else if (randomValue == 3) {
			battle(player, 92);
		}
	}
	else if (player.posR > 12 || (currentTime > 120 && currentTime < 170)) {
		
		int randomValue = rand() % 1000;

		// 0.3% = 크리퍼
		if (randomValue < 3) {
			battle(player, 50);
		}
		// 0.3% = 스켈레톤
		else if (randomValue < 6) {
			battle(player, 51);
		}
		// 0.3% = 거미
		else if (randomValue < 9) {
			battle(player, 52);
		}
		// 0.3% = 좀비
		else if (randomValue < 12) {
			battle(player, 54);
		}
		// 0.3% = 엔더맨
		else if (randomValue < 15) {
			battle(player, 58);
		}
	}
}

void World::useItemInWorld() {
	// 1. 손에 든 아이템이 사용 가능한 아이템인지 확인하기
	if ((isItemIDUsable[player.HandItemID] & USE_NORMAL) == 0) {
		TextBuffer.push("현재 손에 든 아이템은 사용할 수 있는 아이템이 아닙니다.");
		return;
	}

	// 2. 사용하기
	if (player.HandItemID == 368) {
		TextBuffer.push("엔더진주를 사용할 방향을 입력하세요.");
		TextBuffer.push("( 플레이어 위치를 기준으로, 상:w, 좌:a, 하:s, 우:d, 취소:x )");
		printWorld();
		printf("입력 : ");
		char Direction; std::cin >> Direction;

		int tempR = player.posR, tempC = player.posC;

		switch (Direction) {
		case 'W':
		case 'w':
			while (tempR >= 0 && world[tempR][tempC].itemID <= 0) {
				tempR--;
			}
			world[player.posR][player.posC].itemID = 0;
			player.posR = tempR + 1;
			world[player.posR][player.posC].itemID = -1;
			break;
		case 'A':
		case 'a':
			while (tempC >= 0 && world[tempR][tempC].itemID <= 0) {
				tempC--;
			}
			world[player.posR][player.posC].itemID = 0;
			player.posC = tempC + 1;
			world[player.posR][player.posC].itemID = -1;
			break;
		case 'S':
		case 's':
			while (tempR < WORLD_HEIGHT && world[tempR][tempC].itemID <= 0) {
				tempR++;
			}
			world[player.posR][player.posC].itemID = 0;
			player.posR = tempR - 1;
			world[player.posR][player.posC].itemID = -1;
			break;
		case 'D':
		case 'd':
			while (tempC < WORLD_WIDTH && world[tempR][tempC].itemID <= 0) {
				tempC++;
			}
			world[player.posR][player.posC].itemID = 0;
			player.posC = tempC - 1;
			world[player.posR][player.posC].itemID = -1;
			break;
		}
		TextBuffer.push("엔더진주를 사용해 순간이동 했습니다!");

	}
	else {
		useItem(player.HandItemID, player);
	}
	
	// 3. 아이템 개수 줄이기
	player.Inventory[player.HandItemID]--;
	if (player.Inventory[player.HandItemID] == 0) {
		player.HandItemID = 0;
	}
}
