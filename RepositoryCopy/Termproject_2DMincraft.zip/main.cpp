﻿#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <windows.h>
#include <random>
#include <map>
#include "itemdata.h"
#include "colorprint.h"
#include "random.h"
#include "basic.h"
#include "Player.h"
#include "Item.h"
#include "Block.h"
#include "World.h"
#include "Monster.h"
#include "Battle.h"

int main() {
	srand(time(0));

	World newWorld = World();
	newWorld.GenerateWorld();
	TextBuffer.push("다음 행동을 입력하세요.");
	TextBuffer.push("행동 목록을 보려면 \"?\" 을 입력하세요.");
	newWorld.printWorld();
	while (true) {
		char command = inputTask();
		switch (command) {
		case 'w':
		case 'a':
		case 's':
		case 'd':
			newWorld.playerMove(command);
			break;
		case 'e':
			newWorld.player.ShowInventory();
			keyboardWait();
			break;
		case 'c':
			newWorld.craft();
			break;
		case 'p':
			newWorld.PlaceBlock();
			break;
		case 'h':
			newWorld.SwitchItem();
			break;
		case 'u':
			newWorld.useItemInWorld();
			break;
		case 'z':
			newWorld.player.ShowStat();
			break;
		case 't':
			TextBuffer.push("< 개발자 명령어 입니다. >");
			TextBuffer.push("다음 행동 중 하나를 입력하세요.");
			TextBuffer.push("g : 아이템 지급");
			TextBuffer.push("m : 디버깅용 몬스터 소환");
			newWorld.printWorld();
			command = inputTask();
			if (command == 'g') {
				newWorld.giveItem();
			}
			else if (command == 'm') {
				TextBuffer.push("소환할 몬스터의 ID를 입력하세요.");
				newWorld.printWorld();
				int Input; std::cin >> Input;
				battle(newWorld.player, Input);
			}
			break;
		case '?':
			TextBuffer.push("w 또는 a 또는 s 또는 d : 해당 방향으로 이동합니다.");
			TextBuffer.push("e : 인벤토리를 확인합니다.");
			TextBuffer.push("c : 아이템을 제작합니다.");
			TextBuffer.push("p : 손에 든 블럭을 설치합니다.");
			TextBuffer.push("h : 손에 들 아이템을 설정합니다.");
			TextBuffer.push("u : 손에 든 아이템을 사용합니다.");
			TextBuffer.push("z : 현재 플레이어의 스탯을 확인합니다.");
		}
		newWorld.printWorld();
		//printf("\n현재 시간 : %d\n", newWorld.currentTime);
	}
}