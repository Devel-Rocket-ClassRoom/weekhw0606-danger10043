#include "Block.h"
#include "colorprint.h"
#include "basic.h"

const std::vector<int> DAWN = { 110, 140, 180 };
extern const std::vector<int> NOON = { 135, 206, 235 };
extern const std::vector<int> DUSK = { 255, 160, 100 };
extern const std::vector<int> MIDNIGHT = { 5, 10, 30 };
// * [블럭추가] 시 printBlock 수정할 것.
void Block::printBlock(int time, int bright) {
	switch (this->itemID) {
	case -1:
		PrintWithColor({ 255, 255, 255 }, { 59, 120, 255 }, " P ");
		break;
	case 0:
		if (posR <= 7) {
			std::vector<int> skyColor;
			if (time < 25) {
				skyColor = linearColor(DAWN, NOON, 0, 24, time);
			}
			else if (time < 75) {
				skyColor = NOON;
			}
			else if (time < 100) {
				skyColor = linearColor(NOON, DUSK, 75, 99, time);
			}
			else if (time < 125) {
				skyColor = linearColor(DUSK, MIDNIGHT, 100, 124, time);
			}
			else if (time < 160) {
				skyColor = MIDNIGHT;
			}
			else {
				skyColor = linearColor(MIDNIGHT, DAWN, 160, 179, time);
			}
			PrintWithColor(skyColor, skyColor, " . ");
		}
		else if (posR >= 8 && posR <= 12) {
			PrintWithColor({ 70, 30, 0 }, { 70, 30, 0 }, " . ");
		}
		else {
			PrintWithColor({ 35, 35, 35 }, { 35, 35, 35 }, " . ");
		}
		break;
	case 1:
		PrintWithColor({ 133, 133, 133 }, { 133, 133, 133 }, ColorNoise, " . ");
		break;
	case 2:
		PrintWithColor({ 9, range(184 + 2 * ColorNoise[1], 0, 255), 16 }, { 10, range(222 + 2 * ColorNoise[1], 0, 255), 19 }, " . ");
		break;
	case 3:
		PrintWithColor({ 135, 70, 18 }, { 135, 70, 18 }, ColorNoise, " . ");
		break;
	case 4:
		PrintWithColor({ 133, 133, 133 }, { 179, 179, 179 }, ColorNoise, ":::");
		break;
	case 5:
		PrintWithColor({ 189, 92, 21 }, { 185, 122, 87 }, ColorNoise, " = ");
		break;
	case 14:
		PrintWithColor({ 255, 255, 50 }, { 180, 180, 133 }, ColorNoise, "`,\'");
		break;
	case 15:
		PrintWithColor({ 237, 183, 136 }, { 160, 145, 133 }, ColorNoise, ";,`");
		break;
	case 16:
		PrintWithColor({ 31, 20, 20 }, { 100, 100, 100 }, ColorNoise, "`.-");
		break;
	case 17:
		PrintWithColor({ 207, 79, 2 }, { 102, 39, 1 }, ColorNoise, "|||");
		break;
	case 18:
		PrintWithColor({ 34, 143, 30 }, { 51, 217, 46 }, ColorNoise, " . ");
		break;
	case 56:
		PrintWithColor({ 0, 255, 255 }, { 133, 170, 170 }, ColorNoise, ";`.");
		break;
	case 58:
		PrintWithColor({ 130, 130, 130 }, { 100, 50, 20 }, ColorNoise, "|X|");
		break;
	case 61:
		PrintWithColor({ 255, 75, 5 }, { 100, 100, 100 }, ColorNoise, " 0 ");
		break;
	}
}

// ===================================================
// ===================================================
// ===================================================

// * [블럭추가] 시 getStrenth() 수정할 것.
int Block::getStrength() {
	switch (itemID) {
	case -1:
		return 99;
		break;
	case 14:
	case 56:
		return 3;
		break;
	case 15:
	case 61:
		return 2;
		break;
	case 1:
	case 4:
	case 16:
		return 1;
		break;
	case 0:
	case 2:
	case 3:
	case 5:
	case 17:
	case 18:
	case 58:
		return 0;
		break;
	default:
		return 0;
	}
}

// ===================================================
// ===================================================
// ===================================================
// * [블럭추가] 시 getItem() 수정할 것.
int Block::getItem() {
	switch (itemID) {
	case -1:
	case 0:
	case 18:
		return -1;
		break;
	case 2:
	case 3:
		return 3;
		break;
	case 1:
	case 4:
		return 4;
		break;
	case 5:
		return 5;
		break;
	case 17:
		return 17;
		break;
	case 58:
		return 58;
		break;
	case 61:
		return 61;
		break;
	case 16:
		return 263;
		break;
	case 56:
		return 264;
		break;
	case 15:
		return 505;
		break;
	case 14:
		return 506;
		break;
	default:
		return 0;
	}
}