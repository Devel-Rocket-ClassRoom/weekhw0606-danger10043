#include "battle.h"
#include "Monster.h"
#include "basic.h"
#include "itemdata.h"
#include "item.h"
#include "colorprint.h"
#include "MonsterFactory.h"
#include <vector>
#include <string>
#include <queue>
#include <windows.h>
#include <iostream>

std::queue<std::string> battleTextBuffer;

void printBattleText() {
	printUILine(BATTLE_UI_WIDTH, 0, 0, true);
	printUILine(1, BATTLE_UI_WIDTH - 2, 1, true);
	while (!battleTextBuffer.empty()) {
		printUILine(0, 2, 0, false);
		printf("%s\n", battleTextBuffer.front().c_str());
		battleTextBuffer.pop();
	}
	printUILine(1, BATTLE_UI_WIDTH - 2, 1, true);
	printUILine(BATTLE_UI_WIDTH, 0, 0, true);
}
 
void playerAttack(Player& player, Monster* enemy) {
	int damage = player.AttackPower + player.WeaponPower;
	int subDamage = (damage / 10) * (rand() % 5 - 2);
	damage += subDamage;
	battleTextBuffer.push("플레이어는 " + enemy->name + "에게 " + std::to_string(enemy->getDamage(damage)) + " 의 피해를 입혔다!");
}

void printBattleInventory(Player& player) {
	std::queue<std::string> inventoryPrintBuffer;
	std::string inventoryTempText = "";

	for (auto it = player.Inventory.begin(); it != player.Inventory.end(); it++) {
		if (it->second <= 0 && it->first != 0)
			continue;

		std::vector<int> textColor;
		if (isItemIDUsable[it->first] & USE_BATTLE) {
			textColor = { 0, 255, 255 };
		}
		else {
			textColor = { 160, 160, 160 };
		}

		inventoryTempText = "      ";
		inventoryTempText += ColorText(textColor, ItemID2ItemName[it->first] + " : " + std::to_string(it->second) + "개");
		while (getTextWidth(inventoryTempText) < (BATTLE_UI_WIDTH - 5)) {
			inventoryTempText += " ";
		}
		inventoryPrintBuffer.push(inventoryTempText);
	}
	
	int itemPrintCount = 0;
	inventoryTempText.clear();
	while (!inventoryPrintBuffer.empty()) {
		inventoryTempText += inventoryPrintBuffer.front();
		inventoryPrintBuffer.pop();
		itemPrintCount++;

		if (itemPrintCount % 3 == 0) {
			battleTextBuffer.push(inventoryTempText);
			inventoryTempText.clear();
		}
	}
	if (!inventoryTempText.empty()) {
		battleTextBuffer.push(inventoryTempText);
	}
	printBattleText();
}

void drawBattleScreen(Monster& enemy) {
	enemy.drawMonster();
	printf("\n");
	printBattleText();
}

std::vector<std::pair<int, int>> getBattleReward(Monster& enemy) {
	std::vector<std::pair<int, int>> result;

	std::map<int, int> rewardCountList;
	std::vector<std::pair<int, int>> rewardList = enemy.rewardList;

	for (std::pair<int, int> reward : rewardList) {
		int randomValue = rand() % 100 + 1;
		if (randomValue <= reward.first) {
			rewardCountList[reward.second]++;
		}
	}

	for (auto it = rewardCountList.begin(); it != rewardCountList.end(); it++) {
		result.push_back({ it->first, it->second });
	}

	return result;
}

bool battle(Player& player, int monsterID) {
	printf("<!> 몬스터와 조우했습니다 <!>\n\n");
	Sleep(1500);
	std::unique_ptr<Monster> enemy = MonsterFactory::createMonster(monsterID);
	battleTextBuffer.push("야생의 " + enemy->name + "이(가) 나타났다!");
	while (true) {
		std::system("cls");
		battleTextBuffer.push("플레이어의 체력 : [ " + std::to_string(player.Health) + " / " + std::to_string(player.MaxHealth) + " ]  |  " + enemy->name + "의 체력 : [ " + std::to_string(enemy->health) + " / " + std::to_string(enemy->maxHealth) + " ]\n\n");
		battleTextBuffer.push("행동을 입력하세요 < [1] 공격  /  [2] 아이템 사용  /  [3] 도망 >");
		drawBattleScreen(*enemy);
		printf("행동 입력 : ");
		int playerAction = 0; std::cin >> playerAction;
		// 플레이어 공격
		if (std::cin.fail() || playerAction <= 0 || playerAction >= 4) {
			std::system("cls");
			std::cin.clear();
			std::cin.ignore(10000, '\n');
			battleTextBuffer.push("잘못된 입력입니다.");
			drawBattleScreen(*enemy);
			continue;
		}
		if (playerAction == 1) {
			std::system("cls");
			playerAttack(player, enemy.get());
			drawBattleScreen(*enemy);
			Sleep(2000);
		}
		// 플레이어 아이템 사용
		else if (playerAction == 2) {
			std::system("cls");
			enemy->drawMonster();
			printf("\n");
			printBattleInventory(player);
			printf("사용할 아이템의 이름을 입력하세요. 취소하려면 X를 입력하세요.\n");
			printf("입력 : ");
			std::string Input; std::cin.ignore(); std::getline(std::cin, Input);

			if (Input == "X" || Input == "x") {
				continue;
			}

			if (ItemName2ItemID[Input] == 0 || player.Inventory[ItemName2ItemID[Input]] <= 0 || ((isItemIDUsable[ItemName2ItemID[Input]] & USE_BATTLE) == 0)) {
				battleTextBuffer.push("보유하지 않은 아이템이거나 사용 가능한 아이템이 아닙니다.");
				std::system("cls");
				drawBattleScreen(*enemy);
				Sleep(2000);
				continue;
			}

			if (Input == "엔더 진주") {
				std::system("cls");
				battleTextBuffer.push("엔더 진주를 사용하여 도망에 성공했습니다!");
				drawBattleScreen(*enemy);
				Sleep(2500);
				return true;
			}

			std::system("cls");
			player.Inventory[ItemName2ItemID[Input]]--;
			BattleUseItem(ItemName2ItemID[Input], player, *enemy);
			drawBattleScreen(*enemy);
			Sleep(2000);
		}
		// 도망
		else if (playerAction == 3) {
			int randomValue = rand() % 1000;
			if (randomValue < 350) {
				std::system("cls");
				battleTextBuffer.push("도망에 성공했습니다!");
				drawBattleScreen(*enemy);
				Sleep(2500);
				return true;
			}
			else {
				std::system("cls");
				battleTextBuffer.push("도망치는데 실패했습니다..");
				drawBattleScreen(*enemy);
				Sleep(2500);
			}
		}
		if (enemy->health <= 0) {
			battleTextBuffer.push(enemy->name + "와(과)의 전투에서 승리했습니다!");
			drawBattleScreen(*enemy);
			Sleep(2500);
			std::system("cls");
			TempTextLine = "";
			std::vector<std::pair<int, int>> rewardList = getBattleReward(*enemy);
			for (std::pair<int, int> reward : rewardList) {
				TempTextLine += ItemID2ItemName[reward.first] + " " + std::to_string(reward.second) + "개, ";
				player.Inventory[reward.first] += reward.second;
			}
			if (!TempTextLine.empty()) {
				TempTextLine.pop_back();
				TempTextLine.pop_back();
				TempTextLine += "를 획득했습니다!";
				battleTextBuffer.push(TempTextLine);
				drawBattleScreen(*enemy);
				Sleep(2500);
			}
			else {
				drawBattleScreen(*enemy);
			}
			return true;
		}
		std::system("cls");
		enemy->attackSkill(player);
		drawBattleScreen(*enemy);
		Sleep(2000);
		if (player.Health <= 0) {
			std::system("cls");
			battleTextBuffer.push("플레이어가 " + enemy->name + "에게 사망했습니다.");battleTextBuffer.push("인벤토리의 모든 아이템을 잃었습니다.");
			player.clearInventory();
			drawBattleScreen(*enemy);
			Sleep(2000);
			return false;
		}
		if (enemy->health <= 0) {
			std::system("cls");
			battleTextBuffer.push(enemy->name + "와(과)의 전투에서 승리했습니다!");
			drawBattleScreen(*enemy);
			Sleep(2500);
			std::system("cls");
			TempTextLine = "";
			std::vector<std::pair<int, int>> rewardList = getBattleReward(*enemy);
			for (std::pair<int, int> reward : rewardList) {
				TempTextLine += ItemID2ItemName[reward.first] + " " + std::to_string(reward.second) + "개, ";
				player.Inventory[reward.first] += reward.second;
			}
			if (!TempTextLine.empty()) {
				TempTextLine.pop_back();
				TempTextLine.pop_back();
				TempTextLine += "를 획득했습니다!";
				battleTextBuffer.push(TempTextLine);
				drawBattleScreen(*enemy);
				Sleep(2500);
			}
			else {
				drawBattleScreen(*enemy);
			}
			return true;
		}
	}
}