#pragma once
#include "Player.h"
#include "Monster.h"

class Item {
public:
	int itemID;
};

void useItem(int itemID, Player& player);

void BattleUseItem(int itemID, Player& player, Monster& enemy);
