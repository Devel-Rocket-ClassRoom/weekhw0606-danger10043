#pragma once
#include "Item.h"
#include <vector>

class Block : public Item {
public:
	int posR = 0, posC = 0;
	std::vector<int> ColorNoise = { 0, 0, 0 };

	void printBlock(int time, int bright);

	int getStrength();

	int getItem();
};