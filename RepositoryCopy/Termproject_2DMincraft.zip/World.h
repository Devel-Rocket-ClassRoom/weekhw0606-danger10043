#pragma once
#include "Player.h"
#include "Block.h"
#include <vector>

extern const std::vector<int> DAWN;
extern const std::vector<int> NOON;
extern const std::vector<int> DUSK;
extern const std::vector<int> MIDNIGHT;

class World {
public:
	std::vector<std::vector<Block>> world;
	int currentTime = 50;
	Player player;

	void GenerateWorld();

	void plantTree(int worldPosR, int worldPosC);

	void SwitchItem();

	void PlaceBlock();

	void craft();

	void giveItem();

	void printWorld();

	bool playerMine(int worldPosR, int worldPosC);

	void playerMove(char direction);

	void tryBattle();

	void useItemInWorld();
};