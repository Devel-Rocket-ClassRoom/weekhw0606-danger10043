#pragma once
#include <string>
#include <map>
#include <queue>
#include <vector>
#include <algorithm>
#include "Player.h"

class Monster {
public:
	int entityID = 0;
	int health = 0;
	int maxHealth = 0;
	int attackPower = 0;
	int defensePower = 0;
	std::string name = "";
	std::vector<std::pair<int, int>> rewardList;

	void setStat(int hp, int ad, int armor);

	virtual ~Monster() = default;

	virtual int getDamage(int damage) {
		this->health -= damage;
		return damage;
	}

	virtual void drawMonster() = 0;

	virtual void attackSkill(Player& player) = 0;

};

// 이 아래부터 몬스터 추가시 수정할 것

// 50, 크리퍼
class Creeper : public Monster {
public:
	int fuse = 3;
	Creeper() : Monster() {
		entityID = 50;
		setStat(100, 150, 0);
		name = "크리퍼";
		rewardList = { {100, 289}, {100, 289}, {50, 289}, {50, 289} };
	};

	void drawMonster() override;
	void attackSkill(Player& player) override;
};

// 51, 스켈레톤
class Skeleton : public Monster {
public:
	Skeleton() : Monster() {
		entityID = 51;
		setStat(110, 20, 0);
		name = "스켈레톤";
		rewardList = { {100, 262}, {100, 262}, {50, 262}, {100, 352}, {100, 352}, {100, 352}, {100, 352}, {50, 352}, {50, 352}, {50, 352}, };
	};

	void drawMonster() override;
	void attackSkill(Player& player) override;
};

// 52, 거미
class Spider : public Monster {
public:
	int attackDecreaseAmount = 0;
	Spider() : Monster() {
		entityID = 52;
		setStat(90, 18, 0);
		name = "거미";
		rewardList = { {100, 287}, {100, 287}, {50, 287}, {50, 287}, };
	};

	int getDamage(int damage) override {
		this->health -= (std::max)(0, damage - attackDecreaseAmount);
		return (std::max)(0, damage - attackDecreaseAmount);
	}

	void drawMonster() override;
	void attackSkill(Player& player) override;
};

// 54, 좀비
class Zombie : public Monster {
public:
	Zombie() : Monster() {
		entityID = 54;
		setStat(130, 15, 0);
		name = "좀비";
		rewardList = { {100, 367}, {70, 367}, {30, 367}, {5, 367}, };
	};

	void drawMonster() override;
	void attackSkill(Player& player) override;
};

// 58, 엔더맨
class Enderman : public Monster {
public:
	bool isUpset = false;

	Enderman() : Monster() {
		entityID = 58;
		setStat(200, 30, 0);
		name = "엔더맨";
		rewardList = { {100, 368}, {100, 368}, {100, 368}, {35, 368}, };
	};

	int getDamage(int damage) override;
	void drawMonster() override;
	void attackSkill(Player& player) override;
};

// 90, 돼지
class Pig : public Monster {
public:
	Pig() : Monster() {
		entityID = 90;
		setStat(60, 0, 0);
		name = "돼지";
		rewardList = { {100, 319}, {70, 319}, {30, 319}, };
	};

	void drawMonster() override;
	void attackSkill(Player& player) override;
};

// 91, 양
class Sheep : public Monster {
public:
	Sheep() : Monster() {
		entityID = 91;
		setStat(60, 0, 0);
		name = "양";
		rewardList = { {100, 423}, {70, 423}, {30, 423}, };
	};

	void drawMonster() override;
	void attackSkill(Player& player) override;
};

// 92, 소
class Cow : public Monster {
public:
	Cow() : Monster() {
		entityID = 92;
		setStat(60, 0, 0);
		name = "소";
		rewardList = { {100, 363}, {70, 363}, {30, 363}, };
	};

	void drawMonster() override;
	void attackSkill(Player& player) override;
};
