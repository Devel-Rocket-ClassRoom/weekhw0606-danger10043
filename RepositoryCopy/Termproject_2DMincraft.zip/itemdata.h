#pragma once

#include <vector>
#include <string>
#include <map>

extern std::map<std::vector<std::pair<int, int>>, std::pair<int, int>> RECIPEBOOK;

extern std::map<int, std::string> ItemID2ItemName;

extern std::map<std::string, int> ItemName2ItemID;

extern std::map<int, std::vector<int>> ItemID2NameColor;

extern std::map<int, int> isItemIDUsable;

enum useFlag {
	USE_NONE = 0,
	USE_NORMAL = 1 << 0,
	USE_BATTLE = 1 << 1,
};