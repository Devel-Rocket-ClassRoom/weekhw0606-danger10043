#pragma once
#include "Player.h"
#include "Monster.h"
#include <queue>
#include <string>

extern std::queue<std::string> battleTextBuffer;

void printBattleText();

void playerAttack(Player& player, Monster* enemy);

void printBattleInventory(Player& player);

void drawBattleScreen(Monster& enemy);

std::vector<std::pair<int, int>> getBattleReward(Monster& enemy);

bool battle(Player& player, int monsterID);