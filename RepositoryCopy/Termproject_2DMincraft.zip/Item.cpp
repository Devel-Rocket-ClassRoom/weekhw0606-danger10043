#include "Item.h"
#include "battle.h"
#include "basic.h"
#include "itemdata.h"

void useItem(int itemID, Player& player) {

	// 돼지고기
	if (itemID == 319) {
		TextBuffer.push("돼지고기를 먹었습니다.");
		TextBuffer.push("체력을 " + std::to_string(player.heal(40)) + " 회복했습니다.");
	}

	// 익힌 돼지고기
	else if (itemID == 320) {
		TextBuffer.push("돼지고기를 먹었습니다.");
		TextBuffer.push("체력을 " + std::to_string(player.heal(100)) + " 회복했습니다.");
	}

	// 소고기
	else if (itemID == 363) {
		TextBuffer.push("소고기를 먹었습니다.");
		TextBuffer.push("체력을 " + std::to_string(player.heal(40)) + " 회복했습니다.");
	}
	
	// 스테이크
	else if (itemID == 364) {
		TextBuffer.push("스테이크를 먹었습니다.");
		TextBuffer.push("체력을 " + std::to_string(player.heal(100)) + " 회복했습니다.");
	}
	
	// 썩은 고기
	else if (itemID == 367) {
		TextBuffer.push("썩은 고기를 먹었습니다.");
		TextBuffer.push("체력을 " + std::to_string(player.heal(20)) + " 회복했습니다.");
	}

	// 엔더 진주
	else if (itemID == 368) {
		// World.cpp 에 구현되어 있음
	}

	// 양고기 
	else if (itemID == 423) {
		TextBuffer.push("양고기를 먹었습니다.");
		TextBuffer.push("체력을 " + std::to_string(player.heal(40)) + " 회복했습니다.");
	}

	// 익힌 양고기
	else if (itemID == 424) {
		TextBuffer.push("익힌 양고기를 먹었습니다.");
		TextBuffer.push("체력을 " + std::to_string(player.heal(100)) + " 회복했습니다.");
	}
}

void BattleUseItem(int itemID, Player& player, Monster& enemy) {

	// 활
	if (itemID == 261) {
		player.Inventory[261]++;
		if (player.Inventory[262] <= 0) {
			battleTextBuffer.push("화살이 없어 활로 " + enemy.name + "를 후려쳤다.");
			int damage = (player.AttackPower + player.WeaponPower) * 8 / 10;
			battleTextBuffer.push("플레이어는 " + enemy.name + "에게 " + std::to_string(enemy.getDamage(damage)) + " 의 피해를 입혔다!");
			return;
		}
		player.Inventory[262]--;

		if (enemy.entityID == 58) {
			battleTextBuffer.push("플레이어는 활을 쏘았으나, 엔더맨은 회피했다.");
			enemy.getDamage(0);
			return;
		}

		if (enemy.maxHealth == enemy.health) {
			battleTextBuffer.push("플레이어는 활을 사용하여 강력한 원거리 저격을 쏘았다!");
			int damage = (player.AttackPower + player.WeaponPower) * 5 / 2;
			battleTextBuffer.push("플레이어는 " + enemy.name + "에게 " + std::to_string(enemy.getDamage(damage)) + " 의 피해를 입혔다!");
		}
		else {
			battleTextBuffer.push("플레이어는 활을 사용하여 화살을 쏘았다.");
			int damage = (player.AttackPower + player.WeaponPower) * 3 / 2;
		}
	}

	// 돼지고기
	if (itemID == 319) {
		battleTextBuffer.push("돼지고기를 먹었다.");
		battleTextBuffer.push("체력을 " + std::to_string(player.heal(40)) + " 회복했다!");
	}

	// 익힌 돼지고기
	else if (itemID == 320) {
		battleTextBuffer.push("익힌 돼지고기를 먹었다.");
		battleTextBuffer.push("체력을 " + std::to_string(player.heal(100)) + " 회복했다!");
	}

	// 소고기
	else if (itemID == 363) {
		battleTextBuffer.push("소고기를 먹었다.");
		battleTextBuffer.push("체력을 " + std::to_string(player.heal(40)) + " 회복했다!");
	}

	// 스테이크
	else if (itemID == 364) {
		battleTextBuffer.push("스테이크를 먹었다.");
		battleTextBuffer.push("체력을 " + std::to_string(player.heal(100)) + " 회복했다!");
	}
	
	// 썩은 고기
	else if (itemID == 367) {
		battleTextBuffer.push("썩은 고기를 먹었다.");
		battleTextBuffer.push("체력을 " + std::to_string(player.heal(20)) + " 회복했다!");
	}

	// 엔더 진주
	else if (itemID == 368) {
		return;
	}

	// 양고기
	else if (itemID == 423) {
		battleTextBuffer.push("양고기를 먹었다.");
		battleTextBuffer.push("체력을 " + std::to_string(player.heal(40)) + " 회복했다!");
	}

	// 익힌 양고기
	else if (itemID == 424) {
		battleTextBuffer.push("양고기를 먹었다.");
		battleTextBuffer.push("체력을 " + std::to_string(player.heal(100)) + " 회복했다!");
	}
}

